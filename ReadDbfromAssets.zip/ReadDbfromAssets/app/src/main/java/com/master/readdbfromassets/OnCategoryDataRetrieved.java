package com.master.readdbfromassets;


import java.util.ArrayList;

/**
 * Created by dhiraj on 19/12/17.
 */

public interface OnCategoryDataRetrieved {
    void onDataRetrieved(ArrayList<CategoryData> categoryDataArrayList, boolean status);
}
