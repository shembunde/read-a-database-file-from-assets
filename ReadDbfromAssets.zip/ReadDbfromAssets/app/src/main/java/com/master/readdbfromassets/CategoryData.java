package com.master.readdbfromassets;

/**
 * Created by dhiraj on 14/10/16.
 */
public class CategoryData {
    String catName;

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }
}
