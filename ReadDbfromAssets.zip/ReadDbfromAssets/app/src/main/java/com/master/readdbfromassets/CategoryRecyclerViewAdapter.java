package com.master.readdbfromassets;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

//Category RecyclerView Adapter
public class CategoryRecyclerViewAdapter extends RecyclerView.Adapter<CategoryRecyclerViewAdapter.MyViewHolder> {

    private ArrayList<CategoryData> categoryArrayList;
    private Context context;

    public CategoryRecyclerViewAdapter(Context context) {
        this.context = context;
    }

    public void setData(ArrayList<CategoryData> categoryArrayList) {
        this.categoryArrayList = categoryArrayList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.list_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        holder.countryName.setText(categoryArrayList.get(position).getCatName());

    }

    @Override
    public int getItemCount() {
        return categoryArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView countryName;
        CardView cardView;

        public MyViewHolder(View view) {
            super(view);
            cardView = (CardView) view.findViewById(R.id.card_view);
            countryName = (TextView) view.findViewById(R.id.text1);
        }
    }
}
