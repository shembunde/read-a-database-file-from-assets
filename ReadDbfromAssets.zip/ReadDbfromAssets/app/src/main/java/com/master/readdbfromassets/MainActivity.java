package com.master.readdbfromassets;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnCategoryDataRetrieved {

    private GetCategoryDataAsyncTask getCategoryDataAsyncTask;

    private RecyclerView mRecyclerView;
    private ProgressBar mProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        //Preparing DB
        DatabaseOpenHelper databaseOpenHelper = new DatabaseOpenHelper(MainActivity.this, getFilesDir().getAbsolutePath());
        try {
            databaseOpenHelper.prepareDataBase();
        } catch (IOException io) {
            throw new Error("Unable to create Database");
        }
        //GET and display Category list from DB
        displayHomePage(databaseOpenHelper);
    }

    private void displayHomePage(DatabaseOpenHelper databaseOpenHelper) {
        //Getting and Setting DATA to Adapter from DB
        if (databaseOpenHelper != null) {
            //TODO call asynctask to load data
            mProgressBar.setVisibility(View.VISIBLE);
            mRecyclerView.setVisibility(View.GONE);
            getCategoryDataAsyncTask = new GetCategoryDataAsyncTask(databaseOpenHelper);
            getCategoryDataAsyncTask.onCategoryDataRetrieved = this;
            getCategoryDataAsyncTask.execute();
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (getCategoryDataAsyncTask != null) {
            getCategoryDataAsyncTask.cancel(true);
        }
    }

    private void init() {
        mProgressBar=findViewById(R.id.insidePB);
        mRecyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(linearLayoutManager);

    }

    @Override
    public void onDataRetrieved(ArrayList<CategoryData> categoryDataArrayList, boolean status) {
        mProgressBar.setVisibility(View.GONE);
        mRecyclerView.setVisibility(View.VISIBLE);
        if (status && categoryDataArrayList.size() > 0) {

            CategoryRecyclerViewAdapter categoryRecyclerViewAdapter = new CategoryRecyclerViewAdapter(getApplicationContext());
            categoryRecyclerViewAdapter.setData(categoryDataArrayList);
            mRecyclerView.setAdapter(categoryRecyclerViewAdapter);
        }
    }
}
